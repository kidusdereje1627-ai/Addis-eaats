"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";

const dishesData = [
  {
    id: "1",
    name: "Special Kitfo",
    price: 320,
    category: "Mains",
    spicy: true,
    description: "A traditional Ethiopian dish prepared with seasoned kitfo.",
  },
  {
    id: "2",
    name: "Shiro Tegabino",
    price: 180,
    category: "Mains",
    spicy: false,
    description: "A delicious Ethiopian chickpea stew.",
  },
  {
    id: "3",
    name: "Chechebsa",
    price: 160,
    category: "Breakfast",
    spicy: false,
    description: "Traditional Ethiopian flatbread breakfast.",
  },
];

type CartItem = {
  id: string;
  name: string;
  price: number;
  quantity: number;
};

export default function DishDetailPage() {
  const params = useParams<{ id: string }>();
  const [added, setAdded] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [dish, setDish] = useState<(typeof dishesData)[number] | null>(null);

  useEffect(() => {
    setDish(dishesData.find((item) => item.id === params.id) ?? null);
  }, [params.id]);

  function addToCart() {
    if (!dish) return;

    try {
      const savedCart = localStorage.getItem("addisEatsCart");
      const parsed: unknown = savedCart ? JSON.parse(savedCart) : [];

      if (!Array.isArray(parsed)) {
        throw new Error("Invalid cart data");
      }

      const cart: CartItem[] = parsed;
      const existing = cart.find((item) => String(item.id) === dish.id);

      let updatedCart: CartItem[];

      if (existing) {
        updatedCart = cart.map((item) =>
          String(item.id) === dish.id
            ? {
                ...item,
                name: dish.name,
                price: dish.price,
                quantity: Math.max(1, Number(item.quantity) || 1) + quantity,
              }
            : item,
        );
      } else {
        updatedCart = [
          ...cart,
          {
            id: dish.id,
            name: dish.name,
            price: dish.price,
            quantity,
          },
        ];
      }

      localStorage.setItem("addisEatsCart", JSON.stringify(updatedCart));
      setAdded(true);
    } catch (error) {
      console.error("Failed to add item to cart:", error);
      alert("Could not add this food to your cart. Please try again.");
    }
  }

  if (!dish) {
    return (
      <main className="mx-auto max-w-4xl p-8">
        <p>Loading dish...</p>
        <Link href="/menu">Back to Menu</Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl p-8">
      <Link
        href="/menu"
        className="mb-6 inline-block text-green-700 hover:underline">
        ← Back to Menu
      </Link>

      <div className="rounded-xl border bg-white p-6 shadow-sm">
        <h1 className="mb-3 text-3xl font-bold">
          {dish.name} {dish.spicy ? "🌶️" : ""}
        </h1>

        <p className="mb-2 text-gray-600">Category: {dish.category}</p>
        <p className="mb-4 text-gray-700">{dish.description}</p>
        <p className="mb-6 text-xl font-semibold">Price: {dish.price} ETB</p>

        <div className="mb-5 flex items-center gap-4">
          <span>Quantity:</span>
          <button
            type="button"
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="rounded border px-3 py-1">
            −
          </button>
          <span>{quantity}</span>
          <button
            type="button"
            onClick={() => setQuantity((q) => q + 1)}
            className="rounded border px-3 py-1">
            +
          </button>
        </div>

        <button
          type="button"
          onClick={addToCart}
          className="mr-3 rounded-lg bg-green-700 px-5 py-3 text-white hover:bg-green-800">
          Add to Cart
        </button>

        <Link
          href="/cart"
          className="inline-block rounded-lg border border-green-700 px-5 py-3 text-green-700 hover:bg-green-50">
          Go to Cart
        </Link>

        {added && (
          <p role="status" className="mt-4 font-medium text-green-700">
            Added to cart successfully!
          </p>
        )}
      </div>
    </main>
  );
}
